# Staff invitations client

Browser-safe root exports input/result schemas, messages, and rejection mapping.
`/server` imports `server-only` and exports `submitStaffInvitation` plus
`sendInvitationToEstl`. The caller supplies verified deployment-scoped staff,
an injected auth client, and a transport configured with a trusted API origin,
credential variable and expected credential environment. The transport performs
site-context and admin-session GET checks before one invitation POST, with no
automatic retries. Pre-dispatch failures mean `not_sent`; uncertain POST outcomes
mean `unavailable`. `sent` means the backend confirmed sending, not recipient
acceptance. Browser visibility never grants authority.

`/confirmation` provides portable Web Request/Response handlers and HTML with
`{siteName}` branding. GET validates and renders but never consumes an invite.
POST requires exact same-origin, verifies only invite tokens, redirects locally,
and preserves a private retry page for temporary failures. Callers own verifying
OTP, applying cookies/session changes, and membership/session policy. The adapter
must copy any outgoing auth cookies onto the returned response where needed.

`/auth-errors` provides Supabase error classification. No credentials, provider
bodies, or invitation tokens are logged. This package changes no database or
provider configuration and performs no request until invoked by the consuming
site's server action. Root exports never import server transport.
