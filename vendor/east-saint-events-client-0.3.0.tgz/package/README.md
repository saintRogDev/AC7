# @east-saint/events-client 0.3.0 candidate

Private, framework-neutral client contracts for ESTL free Events and the explicit paid Events API. Local candidate adoption is in progress for Innovators, AC7, MDI and Dancing Doula; this does not establish hosted acceptance. It is not a published registry package.

Exports: contract types and adapter interfaces, runtime success-response validation, token-shape helpers, and cryptographic submission-idempotency key generation. `validateEventsResponse` expects a pathname without query parameters and an uppercase HTTP method, as existing transports provide. It validates response shape, not authentication, authorization or business correctness. Callers retain a key for unchanged payload retries; calling the generator again creates a new intent.

## Extraction boundary

The four source files were byte-identical in AC7 and MDI before extraction. The adapter's relative import now uses `.js` for emitted ESM. The unused synthetic `newDemoToken` generator is deliberately excluded. All other executable validation/idempotency behavior is preserved. ESTL remains authoritative for reservations, verification codes, tickets, capacity and admission.

Branding, React components, Next.js routes/actions, server-only credential access, site-context validation, Supabase auth, staff role checks, environment/tenant mapping, visitor attribution, email, QR camera code and deployment flags remain outside this package. No site keys or environment variables belong here.

## Build and test

From the ESTL repository with its existing dependencies installed:

```sh
pnpm exec tsc -p packages/events-client/tsconfig.json
cd packages/events-client
../../node_modules/.bin/vitest run --config vitest.config.ts
```

Build emits ESM plus declarations in ignored `dist/`. Node 22.12 or newer is required. Export defaults also support synchronous CommonJS `require()` through Node’s ESM loader, as exercised by the Dancing Doula test runtime and the isolated artifact check. Explicit exports support the root and `/types`, `/adapter`, `/response-schema`, `/idempotency` subpaths. The package declares Zod as a runtime dependency. Root CI builds and tests this package. Create a distributable artifact with `npm pack --ignore-scripts` after the build; the tarball contains only declarations, emitted modules, package metadata and this README. Private registry publication and site adoption remain separate rollout decisions.

## Deliberate per-site migration

1. Build and distribute a pinned, reviewed package artifact through the chosen private delivery mechanism; do not depend on another checkout's source paths in production.
2. Replace imports for only the exported contracts/helpers. Preserve local adapter implementations, tenant mapping, auth and branding. Keep any synthetic fixture generator in test/demo-only code.
3. Run that site's contract, malformed-response, retry, auth/tenant and check-in suites, typecheck and build. Review generated browser bundles for server-only configuration leakage.
4. Verify its exact Preview SHA and sandbox flow before merging. Record the package version and artifact integrity in the site's lockfile/release evidence.
5. Remove the replaced copies only once the consuming site passes acceptance. Update sites independently; extraction alone does not synchronize existing copies.

## External ticket promotion (0.1.1)

`@east-saint/events-client/catalog` adds `parseExternalEventCatalog`, `selectExternalEvents`, and `externalTicketAction`. The original 0.1.1 release provided catalog helpers; 0.1.2 adds management contracts backed by the ESTL external event API. Existing core registration contracts are unchanged. The unreleased 0.2 draft is superseded by the explicit /paid 0.3 contract candidate below.

Each entry contains `id` (UUID), `slug`, `title`, `description`, nullable `image_url` and `image_alt`, `location`, ISO timestamps `starts_at`/`ends_at`, IANA `timezone`, `status` (`draft`, `published`, `cancelled`), and `ticketing: { mode: 'external', url, provider, availability }`. Availability is `available`, `sold_out`, or `coming_soon` and must be maintained by the site owner; this package does not synchronize Posh inventory. Flyer and ticket URLs must be public HTTPS URLs. Links open on the provider; do not fetch them or treat clicks as purchases.

An empty array is a valid empty calendar. Malformed catalogs throw and should show an error, never an empty state. Selection hides drafts, retains cancellation notices, sorts upcoming events ascending and past events descending, and uses the end timestamp to archive. Ticket actions are unavailable for draft, cancelled, ended, sold-out or coming-soon entries. A selected event's timezone controls display; consumers own presentation.

Innovators installs a pinned tarball in `vendor/` with lockfile integrity. Its persisted catalog is empty until staff create and publish real events. Synthetic events belong only in development fixtures and must not be included in production builds. Manage promotions through the authenticated admin UI. Native registration/checkout remains a separate adapter; never route an external listing into it.

## External event management (0.1.2)

`externalEventWriteSchema` validates `{event, revision}`; revision zero creates an
ID and updates require the last observed positive revision. Server errors include
409 for stale revision or duplicate slug, 422 for invalid input, and 404 when an
update does not belong to the authenticated organization. Keep failed edits in
the form; never silently retry a conflicting write with a newer revision.
`managedExternalEventSchema` and `managedExternalCatalogSchema` validate saved
records and admin lists. Public catalogs retain the original event-only shape.

ESTL endpoints: GET/POST `/v1/admin/external-events` require existing merchant
(manager/admin) authorization and site authority. GET `/v1/external-events`
requires a site credential and hides drafts. Responses use `{data: ...}`; list
data is `{events: [...]}`, write data is `{event, revision}`. Native registration
and payment routes are unchanged. Companion `external_events` storage has RLS and
no direct browser grants; service-only writes use tenant-scoped revision checks.
The additive migration must be approved/applied before hosted acceptance.

### Flyer uploads

`MAX_EXTERNAL_EVENT_FLYER_BYTES`, `EXTERNAL_EVENT_FLYER_TYPES` and
`externalEventFlyerSchema` define the upload limits and `{id, url}` result.
POST `/v1/admin/external-events/flyers` accepts raw image bytes with the matching
Content-Type (JPEG, PNG, WebP, at most 3 MB). Existing merchant authentication is
required. The server fully decodes with the existing isolated image decoder,
reserves a tenant-scoped private object, and returns an attachment URL only after
storage succeeds. 413 means oversized, 422 invalid image, 429 upload quota and
503 unavailable. Do not automatically retry ambiguous upload failures.

GET `/v1/admin/external-events/flyers/:id` previews an owned ready upload.
GET `/v1/external-events/flyers/:id` serves only flyers referenced by a current
published/cancelled event; draft, replaced and unattached uploads are not public.
All responses are no-store. Save the URL and alternative text on the event to
attach it. Uploading alone does not publish or modify an event.

Apply both external-event migrations before release. The flyer migration requires
Storage RLS and no broad browser policies; it fails rather than weakening an
existing policy. Private abandoned/replaced objects are retained; no destructive
cleanup is performed by this release.


## Paid ticket contract candidate 0.3

The explicit `/paid` export adds validated purchase, offering and individual ticket
contracts plus injected server adapters. It does not enable ticket sales: the
backend, provider integration and client adoption remain under implementation.
Existing free and external catalog exports are retained. The generic free response
validator rejects paid paths; use `validatePaidEventsResponse` for those routes.

A purchase accepts a quantity from 1 to 100; the server additionally enforces the
offering's `max_per_purchase` and available capacity. Offerings expose a unit price,
while purchases snapshot price and quantity. Confirmed purchases require exactly
that many distinct admission IDs. Ticket retrieval returns a collection with
independent QR credentials; duplicate credentials or mixed event/purchase scope
are rejected. Monetary totals are checked against unit price times quantity.
The limit of 100 is a contract safety bound, not a promise that every event sells
100 tickets per checkout. Staff configure each event's lower limit.

This replaces the unpublished one-ticket draft, not an installed paid contract.
See `docs/paid-events-expansion.md` for scope and rollout, and
`docs/contracts/paid-events-v1.md` for server requirements. Native paid selling
must remain disabled until its server and hosted payment acceptance pass.
